
public class TextChess {

	public static void main(String[] args) {
		GameMenu.baseMenu();
	}
}
